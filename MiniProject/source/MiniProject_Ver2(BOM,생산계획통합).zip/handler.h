#ifndef __HANDLER_H__
#define __HANDLER_H__

#pragma once
#include"Item.h"
//#include"PoP.h"

class Plan
{
private:
	string Err_sirial;
	int Plan_date;
	int Amount;


public:
	Plan(const string plan_sirial, int plan_date, int Amount) : Plan_date(plan_date), Amount(Amount)
	{
		Err_sirial = plan_sirial;
	}
	//handler�� �Ѱ��� �����ȹ �迭�� ���������ϴ� �Լ�
	int getAmount() { return Amount; }
	string getMemSrial() { return Err_sirial; }

	virtual void Print_Plan() const
	{
		cout << "Plan Sirial : " << Err_sirial << endl;
		cout << "Plan date : " << Plan_date << endl;
		cout << "Plan amount : " << Amount << endl;
	}
};


class Handler
{
private:
	int Num_Memproduct = 0;
	Plan* stub[100];
	
	CPU cpu[100];
	int cpu_count = 0;

	MB mb[100];
	int mb_count = 0;

	Memorry ram[100];
	int ram_count = 0;

	HDD hdd[100];
	int hdd_count = 0;

	SSD ssd[100];
	int ssd_count = 0;

	Power pow[100];
	int pow_count = 0;

	Case case1[100];
	int case1_count = 0;

	Software os[100];
	int os_count = 0;

	BOM *temp[100];
	int Num_product = 0;

    BOM temp1[100];
    int Num_product1 = 0;

    //POP *pop[100];
    int number = 0;

public:
	Handler(void);

	// ���õ������Է�
	void Init_Sample_ItemInfo(void);

	// ���θ޴�
	void Menu_Main(void);

	// BOM
	void Menu_BOM();
	void Add_BOM();
	void Delete_BOM();
	void Show_BOM();

	// �����ȹ
	void Menu_ManufacturePlanning();
	void Add_ManufacturePlanning();
	void Delete_ManufacturePlanning();
	void Show_ManufacturePlanning();

	// ����
	void manufature();

	// �ҷ�����
	void Show_NGInfo();

};

#endif 
