#include<iostream>
#include<cstring>
#include<vector>
#include<Windows.h>

#pragma warning(disable:4996)

using namespace std;

class Software
{
private:
	char* Software_Name;				// Software �̸�
	char* Software_Num;				// Software ǰ��
	char* Software_Searial;			// Software �ø����ȣ
public:
	Software() { }
	Software(const char* aSoftware_Name, const char* aSoftware_Num, const char* aSoftware_Searial)
	{
		Software_Name = new char[strlen(aSoftware_Name) + 1];
		strcpy(Software_Name, aSoftware_Name);

		Software_Num = new char[strlen(aSoftware_Num) + 1];
		strcpy(Software_Num, aSoftware_Num);

		Software_Searial = new char[strlen(aSoftware_Searial) + 1];
		strcpy(Software_Searial, aSoftware_Searial);
	}

	void print_software_Info() const
	{
		cout << " < SoftWare Info > " << endl;
		cout << this->Software_Name << endl;
		cout << this->Software_Num << endl;
		cout << this->Software_Searial << endl << endl;
	}
};

class Power
{
private:
	char* Power_Name;				// Power �̸�
	char* Power_Num;				// Power ǰ��
	char* Power_Searial;			// Power �ø����ȣ
public:
	Power() { }
	Power(const char* aPower_Name, const char* aPower_Num, const char* aPower_Searial)
	{
		Power_Name = new char[strlen(aPower_Name) + 1];
		strcpy(Power_Name, aPower_Name);

		Power_Num = new char[strlen(aPower_Num) + 1];
		strcpy(Power_Num, aPower_Num);

		Power_Searial = new char[strlen(aPower_Searial) + 1];
		strcpy(Power_Searial, aPower_Searial);
	}

	void print_Power_Info() const
	{
		cout << " < Power Info > " << endl;
		cout << this->Power_Name << endl;
		cout << this->Power_Num << endl;
		cout << this->Power_Searial << endl << endl;
	}
};

class Case
{
private:
	char* Case_Name;				// Case �̸�
	char* Case_Num;				// Case ǰ��
	char* Case_Searial;			// Case �ø����ȣ
public:
	Case() { }
	Case(const char* aCase_Name, const char* aCase_Num, const char* aCase_Searial)
	{
		Case_Name = new char[strlen(aCase_Name) + 1];
		strcpy(Case_Name, aCase_Name);

		Case_Num = new char[strlen(aCase_Num) + 1];
		strcpy(Case_Num, aCase_Num);

		Case_Searial = new char[strlen(aCase_Searial) + 1];
		strcpy(Case_Searial, aCase_Searial);
	}

	void print_Case_Info() const
	{
		cout << " < Case Info > " << endl;
		cout << this->Case_Name << endl;
		cout << this->Case_Num << endl;
		cout << this->Case_Searial << endl << endl;
	}
};

class SSD
{
private:
	char* SSD_Name;				// SSD �̸�
	char* SSD_Num;				// SSD ǰ��
	char* SSD_Searial;			// SSD �ø����ȣ
public:
	SSD() { }
	SSD(const char* aSSD_Name, const char* aSSD_Num, const char* aSSD_Searial)
	{
		SSD_Name = new char[strlen(aSSD_Name) + 1];
		strcpy(SSD_Name, aSSD_Name);

		SSD_Num = new char[strlen(aSSD_Num) + 1];
		strcpy(SSD_Num, aSSD_Num);

		SSD_Searial = new char[strlen(aSSD_Searial) + 1];
		strcpy(SSD_Searial, aSSD_Searial);
	}

	void print_SSD_Info() const
	{
		cout << " < SSD Info > " << endl;
		cout << this->SSD_Name << endl;
		cout << this->SSD_Num << endl;
		cout << this->SSD_Searial << endl << endl;
	}
};

class HDD
{
private:
	char* HDD_Name;				// HDD �̸�
	char* HDD_Num;				// HDD ǰ��
	char* HDD_Searial;			// HDD �ø����ȣ
public:
	HDD() { }
	HDD(const char* aHDD_Name, const char* aHDD_Num, const char* aHDD_Searial)
	{
		HDD_Name = new char[strlen(aHDD_Name) + 1];
		strcpy(HDD_Name, aHDD_Name);

		HDD_Num = new char[strlen(aHDD_Num) + 1];
		strcpy(HDD_Num, aHDD_Num);

		HDD_Searial = new char[strlen(aHDD_Searial) + 1];
		strcpy(HDD_Searial, aHDD_Searial);
	}

	void print_HDD_Info() const
	{
		cout << " < HDD Info > " << endl;
		cout << this->HDD_Name << endl;
		cout << this->HDD_Num << endl;
		cout << this->HDD_Searial << endl << endl;
	}
};

class Memorry
{
private:
	char* Memorry_Name;				// Memorry �̸�
	char* Memorry_Num;				// Memorry ǰ��
	char* Memorry_Searial;			// Memorry �ø����ȣ
public:
	Memorry() { }
	Memorry(const char* aMemorry_Name, const char* aMemorry_Num, const char* aMemorry_Searial)
	{
		Memorry_Name = new char[strlen(aMemorry_Name) + 1];
		strcpy(Memorry_Name, aMemorry_Name);

		Memorry_Num = new char[strlen(aMemorry_Num) + 1];
		strcpy(Memorry_Num, aMemorry_Num);

		Memorry_Searial = new char[strlen(aMemorry_Searial) + 1];
		strcpy(Memorry_Searial, aMemorry_Searial);
	}

	void print_Memorry_Info() const
	{
		cout << " < Memorry Info > " << endl;
		cout << this->Memorry_Name << endl;
		cout << this->Memorry_Num << endl;
		cout << this->Memorry_Searial << endl << endl;
	}
};

class MB
{
private:
	char* MB_Name;				// MB �̸�
	char* MB_Num;				// MB ǰ��
	char* MB_Searial;			// MB �ø����ȣ
public:
	MB() { }
	MB(const char* aMB_Name, const char* aMB_Num, const char* aMB_Searial)
	{
		MB_Name = new char[strlen(aMB_Name) + 1];
		strcpy(MB_Name, aMB_Name);

		MB_Num = new char[strlen(aMB_Num) + 1];
		strcpy(MB_Num, aMB_Num);

		MB_Searial = new char[strlen(aMB_Searial) + 1];
		strcpy(MB_Searial, aMB_Searial);
	}
	void print_MB_Info() const
	{
		cout << " < MB Info > " << endl;
		cout << this->MB_Name << endl;
		cout << this->MB_Num << endl;
		cout << this->MB_Searial << endl << endl;
	}
};


class CPU
{
private:
	char* CPU_Name;				// CPU �̸�
	char* CPU_Num;				// CPU ǰ��
	char* CPU_Searial;			// CPU �ø����ȣ
public:
	CPU() { }
	CPU(const char* aCPU_Name, const char* aCPU_Num, const char* aCPU_Searial)
	{
		CPU_Name = new char[strlen(aCPU_Name) + 1];
		strcpy(CPU_Name, aCPU_Name);

		CPU_Num = new char[strlen(aCPU_Num) + 1];
		strcpy(CPU_Num, aCPU_Num);

		CPU_Searial = new char[strlen(aCPU_Searial) + 1];
		strcpy(CPU_Searial, aCPU_Searial);
	}
	void print_cpu_Info() const
	{
		cout << " < CPU Info > " << endl;
		cout << this->CPU_Name << endl;
		cout << this->CPU_Num << endl;
		cout << this->CPU_Searial << endl << endl;
	}
};

class product2 : public CPU, public MB, public Memorry, public HDD, public SSD, public Case, public Power, public Software
{
private:
	char* Product_Searial;
	CPU* cpu;
	MB* mb;
	Memorry* ram;
	HDD* hdd;
	SSD* ssd;
	Case* pc_case;
	Power* pow;
	Software* software_os;

public:
	product2(const char* aProduct_Searial, CPU& acpu, MB& amb, Memorry& aram, HDD& ahdd, SSD& assd, Power& apow, Case& apc_case, Software& asoftware_os)
		//:cpu(acpu) mb(amb), ram(aram), hdd(ahdd), ssd(assd), pc_case(apc_case), pow(apow), software_os(asoftware_os)
	{
		// ��������� ������ �̹Ƿ� ����� ����ų �༮�� �ӽ÷� ����������
		cpu = new CPU(acpu);
		mb = new MB(amb);
		ram = new Memorry(aram);
		hdd = new HDD(ahdd);
		ssd = new SSD(assd);
		pc_case = new Case(apc_case);
		pow = new Power(apow);
		software_os = new Software(asoftware_os);

		Product_Searial = new char[strlen(aProduct_Searial) + 1];
		strcpy(Product_Searial, aProduct_Searial);
	}

	void Print_produt() const
	{
		// �� Ŭ������ ����� private�̹Ƿ� �ش� Ŭ�������� �Լ��� �����ؾ� ����� ���� ��������
		// ��, print_cpu_Info();�� �׳� ���� '< SoftWare Info >' ������� ����� ����� �� ��ȸ�� �Ұ���!
		cpu->print_cpu_Info();
		mb->print_MB_Info();
		ram->print_Memorry_Info();
		hdd->print_HDD_Info();
		ssd->print_SSD_Info();
		pc_case->print_Case_Info();
		pow->print_Power_Info();
		software_os->print_software_Info();
	}

};


int main(void)
{
	// ���õ�����
	CPU cpu1("CPU1", "CPU001", "20220330-CP1-001");
	CPU cpu2("CPU2", "CPU002", "20220330-CP2-001");
	CPU cpu3("CPU3", "CPU003", "20220330-CP3-001");

	MB mb1("MB1", "MB001", "20220330-MB1-001");
	MB mb2("MB2", "MB002", "20220330-MB2-001");
	MB mb3("MB3", "MB003", "20220330-MB3-001");

	Memorry ram1("ram1", "ram001", "20220330-ram1-001");
	Memorry ram2("ram2", "ram002", "20220330-ram2-001");
	Memorry ram3("ram3", "ram003", "20220330-ram3-001");

	HDD hdd1("hdd1", "hdd001", "20220330-hdd1-001");
	HDD hdd2("hdd2", "hdd002", "20220330-hdd2-001");
	HDD hdd3("hdd3", "hdd003", "20220330-hdd3-001");

	SSD ssd1("ssd1", "ssd001", "20220330-ssd1-001");
	SSD ssd2("ssd2", "ssd002", "20220330-ssd2-001");
	SSD ssd3("ssd3", "ssd003", "20220330-ssd3-001");

	Power pow1("pow1", "pow001", "20220330-pow1-001");
	Power pow2("pow2", "pow002", "20220330-pow2-001");
	Power pow3("pow3", "pow003", "20220330-pow3-001");

	Case case1("case1", "case1001", "20220330-case1-001");
	Case case2("case2", "case1002", "20220330-case2-001");
	Case case3("case3", "case1003", "20220330-case3-001");

	Software os1("os1", "os1001", "20220330-os1-001");
	Software os2("os2", "os1002", "20220330-os2-001");
	Software os3("os3", "os1003", "20220330-os3-001");
	
	int Num_product = 0;

	product2* stub[100];

	stub[Num_product++] = new product2("PC02", cpu1, mb2, ram1, hdd3, ssd1, pow3, case2, os1);
	stub[0]->Print_produt();

	return 0;
}
